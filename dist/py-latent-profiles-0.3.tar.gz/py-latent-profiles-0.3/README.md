# PyLPA

This is a Python package that can be used to run Gaussian mixture models with different constraints on means, variances and covariances. 
It can thus be used to run latent profile analysis, including multiple group analysis.
